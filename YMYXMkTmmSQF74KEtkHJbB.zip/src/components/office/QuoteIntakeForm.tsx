
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Save, Send, Briefcase, CheckCircle } from 'lucide-react';
import { FloorPlanBuilder } from './FloorPlanBuilder';
import { useAuth } from '@/hooks/useAuth';

interface QuoteIntakeFormProps {
  quoteId?: string;
  onSuccess: () => void;
  onCancel: () => void;
}

interface QuoteData {
  // Customer info
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  customer_address: string;
  project_name: string;
  
  // Building dimensions
  width: number;
  length: number;
  eave: number;
  pitch: string;
  truss: string;
  
  // Foundation & Floor
  foundation_type: string;
  floor_type: string;
  soffit_type: string;
  
  // Structure & Design
  snow_load: number;
  wind_load: number;
  building_use: string;
  
  // Exterior Colors
  roof_material: string;
  roof_color: string;
  trim_color: string;
  wainscot_enabled: boolean;
  
  // Overhang
  overhang_same_all: boolean;
  overhang_front: number;
  overhang_back: number;
  overhang_left: number;
  overhang_right: number;
  
  // Insulation
  insulation_type: string;
  
  // Special Features
  has_loft: boolean;
  has_porch: boolean;
  
  // Utilities
  has_plumbing: boolean;
  has_electrical: boolean;
  has_hvac: boolean;
  
  // Notes
  site_notes: string;
  structural_notes: string;
  
  // Status and price
  status: string;
  estimated_price: number | null;
}

export function QuoteIntakeForm({ quoteId, onSuccess, onCancel }: QuoteIntakeFormProps) {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [existingQuote, setExistingQuote] = useState<any>(null);
  const [currentQuoteId, setCurrentQuoteId] = useState<string | undefined>(quoteId);
  
  const [formData, setFormData] = useState<QuoteData>({
    customer_name: '',
    customer_email: '',
    customer_phone: '',
    customer_address: '',
    project_name: '',
    width: 30,
    length: 40,
    eave: 10,
    pitch: '4/12',
    truss: '', // Added missing comma here
    foundation_type: '',
    floor_type: '',
    soffit_type: '',
    snow_load: 0,
    wind_load: 0,
    building_use: '',
    roof_material: '',
    roof_color: '',
    trim_color: '',
    wainscot_enabled: false,
    overhang_same_all: true,
    overhang_front: 12,
    overhang_back: 12,
    overhang_left: 12,
    overhang_right: 12,
    insulation_type: '',
    has_loft: false,
    has_porch: false,
    has_plumbing: false,
    has_electrical: false,
    has_hvac: false,
    site_notes: '',
    structural_notes: '',
    status: 'draft',
    estimated_price: null,
  });

  useEffect(() => {
    if (quoteId) {
      setCurrentQuoteId(quoteId);
      loadQuote();
    }
  }, [quoteId]);

  async function loadQuote() {
    if (!quoteId) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('quotes')
        .select('*')
        .eq('id', quoteId)
        .single();

      if (error) throw error;

      setExistingQuote(data);
      setFormData({
        customer_name: data.customer_name || '',
        customer_email: data.customer_email || '',
        customer_phone: data.customer_phone || '',
        customer_address: data.customer_address || '',
        project_name: data.project_name || '',
        width: data.width || 30,
        length: data.length || 40,
        eave: data.eave || 10,
        pitch: data.pitch || '4/12',
        truss: data.truss || '',
        foundation_type: data.foundation_type || '',
        floor_type: data.floor_type || '',
        soffit_type: data.soffit_type || '',
        snow_load: data.snow_load || 0,
        wind_load: data.wind_load || 0,
        building_use: data.building_use || '',
        roof_material: data.roof_material || '',
        roof_color: data.roof_color || '',
        trim_color: data.trim_color || '',
        wainscot_enabled: data.wainscot_enabled || false,
        overhang_same_all: data.overhang_same_all !== false,
        overhang_front: data.overhang_front || 12,
        overhang_back: data.overhang_back || 12,
        overhang_left: data.overhang_left || 12,
        overhang_right: data.overhang_right || 12,
        insulation_type: data.insulation_type || '',
        has_loft: data.has_loft || false,
        has_porch: data.has_porch || false,
        has_plumbing: data.has_plumbing || false,
        has_electrical: data.has_electrical || false,
        has_hvac: data.has_hvac || false,
        site_notes: data.site_notes || '',
        structural_notes: data.structural_notes || '',
        status: data.status || 'draft',
        estimated_price: data.estimated_price,
      });
    } catch (error: any) {
      console.error('Error loading quote:', error);
      toast.error('Failed to load quote');
    } finally {
      setLoading(false);
    }
  }

  async function handleSaveDraft() {
    await saveQuote('draft');
  }

  async function handleSubmit() {
    await saveQuote('submitted');
  }

  async function saveQuote(status: string) {
    console.log('🔷 saveQuote called with status:', status);
    console.log('🔷 Current formData:', formData);
    console.log('🔷 Current quoteId:', currentQuoteId);
    console.log('🔷 Current profile:', profile);
    
    // Validate user session FIRST
    if (!profile?.id) {
      console.error('❌ Cannot save quote: User profile not loaded or no user ID');
      toast.error('Unable to save: User session not found. Please refresh and try again.');
      return;
    }
    
    setSaving(true);

    try {
      // Helper to clean string values - returns null if empty
      const cleanStr = (val: any): string | null => {
        if (val === null || val === undefined) return null;
        const trimmed = String(val).trim();
        return trimmed === '' ? null : trimmed;
      };

      // Helper to clean number values - NEVER returns NaN
      const cleanNum = (val: any, required: boolean = false): number | null => {
        // Handle empty/null/undefined
        if (val === null || val === undefined || val === '') {
          return required ? 0 : null;
        }
        
        // Convert to number
        const num = Number(val);
        
        // Check for NaN and return default
        if (isNaN(num) || !isFinite(num)) {
          console.warn(`⚠️ Invalid number value: ${val}, using ${required ? 0 : 'null'}`);
          return required ? 0 : null;
        }
        
        return num;
      };

      // Validate required fields FIRST
      const width = cleanNum(formData.width, true) || 30; // Default to 30 if invalid
      const length = cleanNum(formData.length, true) || 40; // Default to 40 if invalid
      
      console.log('🔷 Sanitized width:', width, 'type:', typeof width);
      console.log('🔷 Sanitized length:', length, 'type:', typeof length);
      
      if (width <= 0) {
        console.error('❌ Invalid width:', width);
        toast.error('Please enter a valid building width (must be greater than 0)');
        setSaving(false);
        return;
      }
      
      if (length <= 0) {
        console.error('❌ Invalid length:', length);
        toast.error('Please enter a valid building length (must be greater than 0)');
        setSaving(false);
        return;
      }
      
      console.log('✅ Width and length validation passed');

      // Build quote data with ONLY valid values
      const quoteData: any = {
        // Required fields - MUST have valid values
        width: width, // Already validated as number > 0
        length: length, // Already validated as number > 0
        status: cleanStr(status) || 'draft',
      };

      // If updating existing quote, include the ID
      if (currentQuoteId) {
        quoteData.id = currentQuoteId;
      }

      // DO NOT include quote_number - let database handle it

      // Optional string fields
      const customerName = cleanStr(formData.customer_name);
      if (customerName) quoteData.customer_name = customerName;
      
      const customerEmail = cleanStr(formData.customer_email);
      if (customerEmail) quoteData.customer_email = customerEmail;
      
      const customerPhone = cleanStr(formData.customer_phone);
      if (customerPhone) quoteData.customer_phone = customerPhone;
      
      const customerAddress = cleanStr(formData.customer_address);
      if (customerAddress) quoteData.customer_address = customerAddress;
      
      const projectName = cleanStr(formData.project_name);
      if (projectName) quoteData.project_name = projectName;
      
      // Dimensions (use cleanNum with required=false to get null for empty values)
      const eave = cleanNum(formData.eave, false);
      if (eave !== null) quoteData.eave = eave;
      
      const pitch = cleanStr(formData.pitch);
      if (pitch) quoteData.pitch = pitch;
      
      const truss = cleanStr(formData.truss);
      if (truss) quoteData.truss = truss;
      
      // Foundation & Floor
      const foundationType = cleanStr(formData.foundation_type);
      if (foundationType) quoteData.foundation_type = foundationType;
      
      const floorType = cleanStr(formData.floor_type);
      if (floorType) quoteData.floor_type = floorType;
      
      const soffitType = cleanStr(formData.soffit_type);
      if (soffitType) quoteData.soffit_type = soffitType;
      
      // Structure (allow 0 values)
      const snowLoad = cleanNum(formData.snow_load, false);
      if (snowLoad !== null) quoteData.snow_load = snowLoad;
      
      const windLoad = cleanNum(formData.wind_load, false);
      if (windLoad !== null) quoteData.wind_load = windLoad;
      
      const buildingUse = cleanStr(formData.building_use);
      if (buildingUse) quoteData.building_use = buildingUse;
      
      // Exterior
      const roofMaterial = cleanStr(formData.roof_material);
      if (roofMaterial) quoteData.roof_material = roofMaterial;
      
      const roofColor = cleanStr(formData.roof_color);
      if (roofColor) quoteData.roof_color = roofColor;
      
      const trimColor = cleanStr(formData.trim_color);
      if (trimColor) quoteData.trim_color = trimColor;
      
      quoteData.wainscot_enabled = Boolean(formData.wainscot_enabled);
      
      // Overhang (allow 0 values)
      quoteData.overhang_same_all = Boolean(formData.overhang_same_all);
      const overhangFront = cleanNum(formData.overhang_front, false);
      if (overhangFront !== null) quoteData.overhang_front = overhangFront;
      
      const overhangBack = cleanNum(formData.overhang_back, false);
      if (overhangBack !== null) quoteData.overhang_back = overhangBack;
      
      const overhangLeft = cleanNum(formData.overhang_left, false);
      if (overhangLeft !== null) quoteData.overhang_left = overhangLeft;
      
      const overhangRight = cleanNum(formData.overhang_right, false);
      if (overhangRight !== null) quoteData.overhang_right = overhangRight;
      
      // Insulation
      const insulationType = cleanStr(formData.insulation_type);
      if (insulationType) quoteData.insulation_type = insulationType;
      
      // Features (always include as boolean)
      quoteData.has_loft = Boolean(formData.has_loft);
      quoteData.has_porch = Boolean(formData.has_porch);
      quoteData.has_plumbing = Boolean(formData.has_plumbing);
      quoteData.has_electrical = Boolean(formData.has_electrical);
      quoteData.has_hvac = Boolean(formData.has_hvac);
      
      // Notes
      const siteNotes = cleanStr(formData.site_notes);
      if (siteNotes) quoteData.site_notes = siteNotes;
      
      const structuralNotes = cleanStr(formData.structural_notes);
      if (structuralNotes) quoteData.structural_notes = structuralNotes;
      
      // Price (allow 0 values)
      const estimatedPrice = cleanNum(formData.estimated_price, false);
      if (estimatedPrice !== null) quoteData.estimated_price = estimatedPrice;

      // Metadata - profile.id is already validated at the top
      quoteData.created_by = profile.id;
      
      if (status === 'submitted' && !existingQuote?.submitted_at) {
        quoteData.submitted_at = new Date().toISOString();
      }

      console.log('💾 Attempting to save quote...');
      console.log('📋 Form data:', formData);
      console.log('📤 Sending to database:', quoteData);
      console.log('📤 JSON stringified:', JSON.stringify(quoteData, null, 2));
      console.log('📤 Width type:', typeof quoteData.width, 'value:', quoteData.width);
      console.log('📤 Length type:', typeof quoteData.length, 'value:', quoteData.length);
      console.log('📤 Status type:', typeof quoteData.status, 'value:', quoteData.status);
      console.log('📤 Has ID:', !!quoteData.id, 'ID value:', quoteData.id);
      console.log('📤 Created by:', quoteData.created_by);
      
      // Validate ALL values to ensure no NaN or invalid types
      for (const [key, value] of Object.entries(quoteData)) {
        if (typeof value === 'number' && (isNaN(value) || !isFinite(value))) {
          console.error(`❌ Invalid number in quoteData[${key}]:`, value);
          toast.error(`Invalid value for ${key}. Please check your input.`);
          setSaving(false);
          return;
        }
      }

      // Use upsert with explicit conflict resolution on 'id'
      const { data, error } = await supabase
        .from('quotes')
        .upsert(quoteData, { onConflict: 'id' })
        .select()
        .single();

      if (error) {
        // Log FULL error details for debugging
        console.error('❌ ========== SUPABASE ERROR ==========');
        console.error('❌ Error Object:', error);
        console.error('❌ Error Message:', error.message);
        console.error('❌ Error Code:', error.code);
        console.error('❌ Error Details:', error.details);
        console.error('❌ Error Hint:', error.hint);
        console.error('❌ Full Error JSON:', JSON.stringify(error, null, 2));
        console.error('❌ Data that was sent:', JSON.stringify(quoteData, null, 2));
        console.error('❌ ====================================');
        
        // Parse error response to get more details
        let userMessage = 'Failed to save quote';
        
        if (error.code === '23502') {
          // NOT NULL violation
          const columnMatch = error.message.match(/column "([^"]+)"/i);
          const columnName = columnMatch ? columnMatch[1] : 'unknown';
          userMessage = `Missing required field: ${columnName}. Please fill in all required information.`;
          console.error(`❌ NULL constraint violation on column: ${columnName}`);
        } else if (error.code === '23505') {
          // Unique violation
          userMessage = 'A quote with this information already exists';
          console.error('❌ Unique constraint violation');
        } else if (error.code === '22P02') {
          // Invalid input syntax
          userMessage = 'Invalid data format - please check all numeric fields';
          console.error('❌ Invalid input syntax for type');
        } else if (error.code === '42501') {
          // Permission denied
          userMessage = 'Permission denied - please check your access rights';
          console.error('❌ Permission denied');
        } else if (error.code === '42703') {
          // Undefined column
          userMessage = 'Database schema mismatch - please contact support';
          console.error('❌ Column does not exist in table');
        } else if (error.message) {
          userMessage = `Database error: ${error.message}`;
          if (error.hint) {
            userMessage += ` (Hint: ${error.hint})`;
          }
        }
        
        toast.error(userMessage, { duration: 10000 });
        setSaving(false);
        return;
      }

      console.log('✅ Quote saved successfully:', data);
      console.log('✅ Returned quote ID:', data.id);

      // CRITICAL: Update currentQuoteId IMMEDIATELY after first save
      // This ensures subsequent saves UPDATE instead of INSERT
      if (!currentQuoteId && data.id) {
        console.log('🆕 First save detected - setting currentQuoteId to:', data.id);
        setCurrentQuoteId(data.id);
        setExistingQuote(data);
        
        // Generate quote number for new quotes
        const quoteNumber = `Q${new Date().getFullYear()}-${String(data.id).slice(0, 6).toUpperCase()}`;
        const { error: updateError } = await supabase
          .from('quotes')
          .update({ quote_number: quoteNumber })
          .eq('id', data.id);

        if (updateError) {
          console.error('⚠️ Error updating quote number:', updateError);
        } else {
          console.log('✅ Quote number generated:', quoteNumber);
        }
        
        toast.success(`Draft saved - Quote #${quoteNumber}`);
      } else {
        console.log('📝 Update existing quote:', currentQuoteId);
        // Update the existing quote data
        setExistingQuote(data);
        toast.success(status === 'draft' ? 'Draft saved successfully' : 'Quote updated successfully');
      }

      // Only call onSuccess if we're submitting (not just saving draft)
      if (status !== 'draft') {
        onSuccess();
      }
    } catch (error: any) {
      console.error('❌ CATCH ERROR:', error);
      console.error('❌ Error name:', error.name);
      console.error('❌ Error stack:', error.stack);
      toast.error(`Error: ${error.message || 'Unknown error occurred'}`, { duration: 5000 });
    } finally {
      setSaving(false);
    }
  }

  async function handleConvertToJob() {
    if (!quoteId) return;

    try {
      setSaving(true);

      // Create job from quote
      const { data: jobData, error: jobError } = await supabase
        .from('jobs')
        .insert({
          name: formData.project_name,
          client_name: formData.customer_name,
          address: formData.customer_address || '',
          description: `Building: ${formData.width}' × ${formData.length}'\n${formData.site_notes || ''}`,
          status: 'active',
          created_by: profile?.id,
        })
        .select()
        .single();

      if (jobError) throw jobError;

      // Update quote with job reference
      const { error: quoteError } = await supabase
        .from('quotes')
        .update({
          status: 'won',
          job_id: jobData.id,
          converted_at: new Date().toISOString(),
        })
        .eq('id', quoteId);

      if (quoteError) throw quoteError;

      toast.success('Quote converted to active job!');
      onSuccess();
    } catch (error: any) {
      console.error('Error converting quote:', error);
      toast.error('Failed to convert quote to job');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-muted-foreground">Loading quote...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Action Buttons */}
      <div className="flex items-center justify-between sticky top-0 bg-background z-10 py-2 border-b">
        <div className="text-sm text-muted-foreground">
          {existingQuote?.status && (
            <span className="capitalize">{existingQuote.status} Quote</span>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onCancel} disabled={saving}>
            Cancel
          </Button>
          <Button variant="outline" onClick={handleSaveDraft} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            Save Draft
          </Button>
          {formData.status === 'draft' && (
            <Button onClick={handleSubmit} disabled={saving}>
              <Send className="w-4 h-4 mr-2" />
              Submit for Estimating
            </Button>
          )}
          {existingQuote && existingQuote.status === 'estimated' && !existingQuote.job_id && (
            <Button onClick={handleConvertToJob} disabled={saving} className="bg-green-600 hover:bg-green-700">
              <Briefcase className="w-4 h-4 mr-2" />
              Convert to Job
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column - Form Fields */}
        <div className="space-y-6">
          {/* Project Info */}
          <Card>
            <CardHeader>
              <CardTitle>Project Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2 col-span-2">
                  <Label>Project Name *</Label>
                  <Input
                    value={formData.project_name}
                    onChange={(e) => setFormData({ ...formData, project_name: e.target.value })}
                    placeholder="Enter project name"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Customer Name *</Label>
                  <Input
                    value={formData.customer_name}
                    onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                    placeholder="Enter customer name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={formData.customer_email}
                    onChange={(e) => setFormData({ ...formData, customer_email: e.target.value })}
                    placeholder="customer@example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    type="tel"
                    value={formData.customer_phone}
                    onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Address</Label>
                  <Input
                    value={formData.customer_address}
                    onChange={(e) => setFormData({ ...formData, customer_address: e.target.value })}
                    placeholder="Enter site address"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Building Dimensions */}
          <Card>
            <CardHeader>
              <CardTitle>Building Dimensions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Width (ft)</Label>
                  <Input
                    type="number"
                    value={formData.width}
                    onChange={(e) => setFormData({ ...formData, width: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Length (ft)</Label>
                  <Input
                    type="number"
                    value={formData.length}
                    onChange={(e) => setFormData({ ...formData, length: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Eave (ft)</Label>
                  <Input
                    type="number"
                    value={formData.eave}
                    onChange={(e) => setFormData({ ...formData, eave: Number(e.target.value) })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Pitch</Label>
                  <Select value={formData.pitch} onValueChange={(value) => setFormData({ ...formData, pitch: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select pitch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3/12">3/12</SelectItem>
                      <SelectItem value="4/12">4/12</SelectItem>
                      <SelectItem value="5/12">5/12</SelectItem>
                      <SelectItem value="6/12">6/12</SelectItem>
                      <SelectItem value="7/12">7/12</SelectItem>
                      <SelectItem value="8/12">8/12</SelectItem>
                      <SelectItem value="10/12">10/12</SelectItem>
                      <SelectItem value="12/12">12/12</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Truss</Label>
                  <Input
                    value={formData.truss}
                    onChange={(e) => setFormData({ ...formData, truss: e.target.value })}
                    placeholder="Truss type"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Foundation & Floor */}
          <Card>
            <CardHeader>
              <CardTitle>Foundation & Floor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Foundation Type</Label>
                  <Select 
                    value={formData.foundation_type} 
                    onValueChange={(value) => setFormData({ ...formData, foundation_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concrete">Concrete</SelectItem>
                      <SelectItem value="gravel">Gravel</SelectItem>
                      <SelectItem value="pier">Pier</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Floor</Label>
                  <Select 
                    value={formData.floor_type} 
                    onValueChange={(value) => setFormData({ ...formData, floor_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select floor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concrete">Concrete</SelectItem>
                      <SelectItem value="wood">Wood</SelectItem>
                      <SelectItem value="none">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Soffit</Label>
                  <Select 
                    value={formData.soffit_type} 
                    onValueChange={(value) => setFormData({ ...formData, soffit_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select soffit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="steel">Steel</SelectItem>
                      <SelectItem value="vinyl">Vinyl</SelectItem>
                      <SelectItem value="none">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Structure & Design */}
          <Card>
            <CardHeader>
              <CardTitle>Structure & Design</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Snow Load (psf)</Label>
                  <Input
                    type="number"
                    value={formData.snow_load}
                    onChange={(e) => setFormData({ ...formData, snow_load: Number(e.target.value) })}
                    placeholder="20"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Wind Load (mph)</Label>
                  <Input
                    type="number"
                    value={formData.wind_load}
                    onChange={(e) => setFormData({ ...formData, wind_load: Number(e.target.value) })}
                    placeholder="90"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Building Use</Label>
                  <Input
                    value={formData.building_use}
                    onChange={(e) => setFormData({ ...formData, building_use: e.target.value })}
                    placeholder="Storage, Garage, etc."
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Exterior Colors */}
          <Card>
            <CardHeader>
              <CardTitle>Exterior Colors</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Roof Material</Label>
                  <Input
                    value={formData.roof_material}
                    onChange={(e) => setFormData({ ...formData, roof_material: e.target.value })}
                    placeholder="Steel, Shingles, etc."
                  />
                </div>
                <div className="space-y-2">
                  <Label>Roof Color</Label>
                  <Input
                    value={formData.roof_color}
                    onChange={(e) => setFormData({ ...formData, roof_color: e.target.value })}
                    placeholder="Color name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Trim Color</Label>
                  <Input
                    value={formData.trim_color}
                    onChange={(e) => setFormData({ ...formData, trim_color: e.target.value })}
                    placeholder="Color name"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 pt-6">
                    <Checkbox
                      id="wainscot"
                      checked={formData.wainscot_enabled}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, wainscot_enabled: checked as boolean })
                      }
                    />
                    <Label htmlFor="wainscot" className="cursor-pointer">
                      Include Wainscot
                    </Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Overhang */}
          <Card>
            <CardHeader>
              <CardTitle>Overhang</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="overhang_same"
                  checked={formData.overhang_same_all}
                  onCheckedChange={(checked) => 
                    setFormData({ ...formData, overhang_same_all: checked as boolean })
                  }
                />
                <Label htmlFor="overhang_same" className="cursor-pointer">
                  Same on all sides
                </Label>
              </div>
              {formData.overhang_same_all ? (
                <div className="space-y-2">
                  <Label>Overhang (inches)</Label>
                  <Input
                    type="number"
                    value={formData.overhang_front}
                    onChange={(e) => {
                      const value = Number(e.target.value);
                      setFormData({ 
                        ...formData, 
                        overhang_front: value,
                        overhang_back: value,
                        overhang_left: value,
                        overhang_right: value,
                      });
                    }}
                  />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Front (inches)</Label>
                    <Input
                      type="number"
                      value={formData.overhang_front}
                      onChange={(e) => setFormData({ ...formData, overhang_front: Number(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Back (inches)</Label>
                    <Input
                      type="number"
                      value={formData.overhang_back}
                      onChange={(e) => setFormData({ ...formData, overhang_back: Number(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Left (inches)</Label>
                    <Input
                      type="number"
                      value={formData.overhang_left}
                      onChange={(e) => setFormData({ ...formData, overhang_left: Number(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Right (inches)</Label>
                    <Input
                      type="number"
                      value={formData.overhang_right}
                      onChange={(e) => setFormData({ ...formData, overhang_right: Number(e.target.value) })}
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Insulation */}
          <Card>
            <CardHeader>
              <CardTitle>Insulation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Insulation Type</Label>
                <Textarea
                  value={formData.insulation_type}
                  onChange={(e) => setFormData({ ...formData, insulation_type: e.target.value })}
                  placeholder="Interior partitions, ceiling, etc."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Special Features */}
          <Card>
            <CardHeader>
              <CardTitle>Special Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="loft"
                    checked={formData.has_loft}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, has_loft: checked as boolean })
                    }
                  />
                  <Label htmlFor="loft" className="cursor-pointer">
                    Loft
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="porch"
                    checked={formData.has_porch}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, has_porch: checked as boolean })
                    }
                  />
                  <Label htmlFor="porch" className="cursor-pointer">
                    Porch
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Utilities */}
          <Card>
            <CardHeader>
              <CardTitle>Utilities</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="plumbing"
                    checked={formData.has_plumbing}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, has_plumbing: checked as boolean })
                    }
                  />
                  <Label htmlFor="plumbing" className="cursor-pointer">
                    Plumbing
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="electrical"
                    checked={formData.has_electrical}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, has_electrical: checked as boolean })
                    }
                  />
                  <Label htmlFor="electrical" className="cursor-pointer">
                    Electrical
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="hvac"
                    checked={formData.has_hvac}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, has_hvac: checked as boolean })
                    }
                  />
                  <Label htmlFor="hvac" className="cursor-pointer">
                    HVAC
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Site/Sketch Notes</Label>
                <Textarea
                  value={formData.site_notes}
                  onChange={(e) => setFormData({ ...formData, site_notes: e.target.value })}
                  placeholder="Site-specific notes and observations"
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label>Structural Notes</Label>
                <Textarea
                  value={formData.structural_notes}
                  onChange={(e) => setFormData({ ...formData, structural_notes: e.target.value })}
                  placeholder="Structural requirements and considerations"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Estimated Price (for office only) */}
          {existingQuote && (
            <Card>
              <CardHeader>
                <CardTitle>Pricing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Estimated Price</Label>
                  <Input
                    type="number"
                    value={formData.estimated_price || ''}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      estimated_price: e.target.value ? Number(e.target.value) : null 
                    })}
                    placeholder="Enter estimated price"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="submitted">Submitted</SelectItem>
                      <SelectItem value="estimated">Estimated</SelectItem>
                      <SelectItem value="won">Won</SelectItem>
                      <SelectItem value="lost">Lost</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column - Floor Plan Builder */}
        <div className="lg:sticky lg:top-6 h-fit">
          <FloorPlanBuilder
            width={formData.width}
            length={formData.length}
            quoteId={currentQuoteId}
          />
        </div>
      </div>
    </div>
  );
}
